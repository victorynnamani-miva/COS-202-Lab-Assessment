# Smart Library Circulation & Automation System (SLCAS)
Victory Nnamani - COS 202 Lab Assessment

## Project Structure
model/         LibraryItem, Book, Magazine, Journal, Borrowable,
                BorrowRecord, UserAccount, LibraryDatabase
controller/    LibraryManager, SearchEngine, SortEngine, BorrowController
gui/           Main, MainWindow, ViewItemsPanel, BorrowPanel,
                AdminPanel, SearchSortPanel, LibraryTableModel,
                StatusCellRenderer
utils/         IDGenerator, FileHandler

## Requirements
- JDK 17 (the version I built and tested with; JDK 11+ should also work,
  since the code only uses `switch` expressions, pattern-matching
  `instanceof`, and `java.time`). No external libraries are required;
  persistence uses a small hand-written JSON-lines reader/writer in
  `utils.FileHandler`.
  
bash
javac model/*.java controller/*.java utils/*.java gui/*.java
java gui.Main

The application starts on a welcome screen (CardLayout). Click
**"Enter System"** to reach the four-tab dashboard:

1. **View Items** : browse the catalogue (double-click a row to register an
   "access" for the frequency cache).
2. **Borrow/Return** : choose an item and a user, then Borrow or Return.
   If the item is unavailable, the user is placed on its reservation queue and automatically issued the item when it becomes free.
3. **Admin** : add new items (Book/Magazine/Journal — the form dynamically
   adds/removes fields based on the chosen type, e.g. a "Peer-reviewed?"
   checkbox only appears for Journals), delete an item by ID, undo the last
   add/delete, import/export the catalogue as a JSON-lines text file, and
   generate reports (most borrowed, overdue users, category distribution,
   most-accessed cache). The Year field validates live as you type.
4. **Search & Sort** : search by **title, author, or type** using Linear,
   Binary, or Recursive search (with a live "N items match" preview as you
   type), and sort by title/author/year using Selection, Insertion, or
   Merge sort. Binary search requires the list to already be sorted on the
   same field, the app will warn you if it isn't.

### Persistence
On startup, the app automatically loads any previously saved catalogue and users from `data/catalogue.json` and `data/users.json` (created next to the compiled classes).
If no saved data is found (first run), sample data (4 books, 3 magazines, 4 journals, 7 users with placeholder patron names) is seeded instead. Data is saved automatically when you close the window, or at any time via File → Save Now.
The Admin tab's Import/Export buttons additionally let you save/load a catalogue to/from any file you choose.
